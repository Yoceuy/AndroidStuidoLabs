package com.example.calc;

import android.annotation.SuppressLint;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    TextView textView;
    double num1=0,num2=0;
    String str = "";
   // String minus = "-";
    boolean check=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        textView.setText("");

    }

    @SuppressLint("SetTextI18n")
    public void nums(View view) {
        Button n = (Button) view;
        textView.setText(textView.getText().toString()+n.getText().toString());
        check=false;
    }
    public void stmt (double a,double b){

       if (!check)
       {
           try {
               b = Double.parseDouble(textView.getText().toString());
           }
           catch (Exception e){
               return;
           }
       }

       // num2=Double.parseDouble(textView.getText().toString());
            switch (str){
                case "+":
                    a+=b;

                    break;
                case "-":
                    a -= b;
                    break;
                case "*":
                    a*=b;
                    break;
                case "/":
                    a/=b;
                    break;
            }

        textView.setText("");
        num1 = a;
        num2 = b;
        check = true;

    }

    public void operation(View view){
        Button sign=(Button) view;

            if(str.equals("")){
                if (!textView.getText().toString().equals(""))
                {
                    str=sign.getText().toString();
                    num1=Double.parseDouble(textView.getText().toString());
                    //stmt(num1,num2);
                    textView.setText("");
                    check=false;
                }
            }else{
                stmt(num1,num2);
                str=sign.getText().toString();
            }

            check=false;

    }
    public void cls(View view){
        textView.setText("");
        num1=0;
        num2=0;
        str="";

    }

    public void result(View view){
        if(str.equals("")&&!textView.getText().equals("")) textView.setText(textView.getText());
        else if(textView.getText().equals("")) textView.setText("");
        else{
            if (!check)num2=Double.parseDouble(textView.getText().toString());
            switch (str){
                case "+":
                    num1+=num2;
                    break;
                case "-":
                    num1 -= num2;
                    break;
                case "*":
                    num1*=num2;
                    break;
                case "/":
                    num1/=num2;
                    break;
            }

            textView.setText(String.valueOf(num1));
            check = true;
            str="";
        }
    }
}
